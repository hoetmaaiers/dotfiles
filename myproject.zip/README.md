# Dotfiles

Link config files using `stow x`. E.g. `stow direnv` links direnv folder to `~/.config/direnv/direnv.toml`

